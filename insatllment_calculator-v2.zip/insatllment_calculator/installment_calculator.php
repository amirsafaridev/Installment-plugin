<?php
/**
 * Plugin Name: Installments Calculator
 * Description: Create Installments Calculator , short code : installment_calculator
 * Version: 1.0.0
 * Author: ArtaCode
 * Author URI: http://artacode.net
 */


defined('ABSPATH') || exit;

if (!defined('ARTA_INSTALLMENT_CALC_PLUGIN_DIR')) {
    define('ARTA_INSTALLMENT_CALC_PLUGIN_FILE', __FILE__);
    define('ARTA_INSTALLMENT_CALC_PLUGIN_DIR', untrailingslashit(dirname(ARTA_INSTALLMENT_CALC_PLUGIN_FILE)));
}


// Main Function And Hook
require __DIR__ . '/includes/main.php';



