<?php
/**
 * --------------------------
 * Autoload Function And Hook
 * --------------------------
 */



add_action('init', 'arta_installment_register_style_and_scripts');
function arta_installment_register_style_and_scripts()
{
    wp_register_script('arta_installment_jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js', array('jquery'), time(), true);
    wp_register_script('arta_installment_bootstrap_js', plugin_dir_url(__DIR__) . 'assets/js/bootstrap.min.js', array('jquery'), time(), true);
    wp_register_script('arta_installment_scripts', plugin_dir_url(__DIR__) . 'assets/js/arta_installment_scripts.js', array('jquery'), time(), true);

    wp_register_style('arta_installment_bootstrap_style', plugin_dir_url(__DIR__) . 'assets/css/bootstrap.min.css', false, time(), 'all');
    wp_register_style('arta_installment_styles', plugin_dir_url(__DIR__) . 'assets/css/arta_installment_styles.css', false, time(), 'all');
}


add_action('wp_enqueue_scripts', 'arta_installment_enqueue_scripts');
function arta_installment_enqueue_scripts()
{
    //javascript
    wp_enqueue_script('arta_installment_jquery');
    wp_enqueue_script('arta_installment_bootstrap_js');
    wp_enqueue_script('arta_installment_scripts');



    wp_localize_script('arta_installment_scripts', 'arta_installment_object',
        array(
            'ajaxurl' => admin_url('admin-ajax.php'),
        )
    );

    //css
    wp_enqueue_style('arta_installment_bootstrap_style');
    wp_enqueue_style('arta_installment_styles');

}

