<?php
//////////////////// Add setting menu to admin panel ///////////////////////////////////////////////
add_action('admin_menu', 'arta_ads_admin_menu');
function arta_ads_admin_menu()
{
    add_menu_page(
        __('تنظیمات اقساطی', 'textdomain'),
        'تنظیمات اقساطی',
        'manage_options',
        'installment_settings',
        'arta_installment_calc_setting',
        '',
        6
    );
}

//////////////////// Setting menu callback /////////////////////////////////////////////////////////
function arta_installment_calc_setting()
{

    $benefit = get_option("arta_installment_benefit", 0);
    if (isset($_POST["submit"])) {
        $benefit = $_POST["arta_installment_benefit"];
        update_option("arta_installment_benefit", $benefit);
    }
    ?>
    <div class="wrap">
        <h1>تنظیمات افزونه پرداخت اقساطی</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <table class="form-table" role="presentation">
                <tbody>
                <tr>
                    <th scope="row"><label for="arta_azmayesh_prepay">درصد سود</label></th>
                    <td>
                        <input name="arta_installment_benefit" type="number" id="arta_installment_benefit"
                               value="<?php echo $benefit; ?>"
                               class="regular-text" style="width: 70px;">
                        ٪

                    </td>

                </tr>
                </tbody>
            </table>
            <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary"
                                     value="ذخیرهٔ تغییرات"></p>
        </form>
    </div>
    <?php
}


//////////////////// Single product installment calculator /////////////////////////////////////////
add_action("woocommerce_after_add_to_cart_quantity", function () {
    global $product;

    $installment_modes = get_posts(array(
        'post_type' => 'my_installment_mode',
        'posts_per_page' => -1,
        'post_status' => 'any',
    ));
    if ($product->is_type('variable')) {
        $product_price = 0;
        ?>
        <script>
            var is_variable = true;
        </script>
        <?php
    } else {
        $product_price = get_post_meta($product->ID, "_regular_price", true);
        ?>
        <script>
            var is_variable = false;
        </script>
        <?php
    }
    $step = 1;
    ?>
    <script>
        var each_payment_price = 0;
        var prepay_cost = 0;
        var static_prepay_cost = 0;
        var final_price = 0;
        var current_product_price =<?php echo $product_price;?>;
    </script>
    <div class="i_would_pay_in_installments_box">
        <label for="i_would_pay_in_installments" style="height: auto;">مایل به پرداخت اقساطی می باشم</label>
        <input type="checkbox" id="i_would_pay_in_installments" name="i_would_pay_in_installments">
    </div>
    <div class="installment_calculator_container">
        <!--- List of modes ----------->
        <div class="modes_container">
            <?php
            $c = 1;
            $mode_available_steps = "";
            foreach ($installment_modes as $mode) {
                if ($c == 1) {
                    $min_month_first = get_post_meta($mode->ID, "installment_min_month", true);
                    $max_month_first = get_post_meta($mode->ID, "installment_max_month", true);
                    $benefit_first = get_post_meta($mode->ID, "installment_monthly_benefit", true);
                    $installment_1_step_first = get_post_meta($mode->ID, "installment_1_step", true) ?? 0;
                    $installment_2_step_first = get_post_meta($mode->ID, "installment_2_step", true) ?? 0;
                    $installment_3_step_first = get_post_meta($mode->ID, "installment_3_step", true) ?? 0;
                    $mode_available_steps = "";
                    if ($installment_1_step_first == 1) {
                        $step = 1;
                    } else {
                        if ($installment_2_step_first == 1) {
                            $step = 2;
                        } else {
                            if ($installment_3_step_first == 1) {
                                $step = 3;
                            }
                        }
                    }
                    if ($installment_1_step_first == 1) {
                        $mode_available_steps .= "1";
                    }
                    if ($installment_2_step_first == 1) {
                        $mode_available_steps .= ",2";
                    }
                    if ($installment_3_step_first == 1) {
                        $mode_available_steps .= ",3";
                    }
                    ?>
                    <script>
                        var min_month =<?php echo $min_month_first ?>;
                        var max_month =<?php echo $max_month_first ?>;
                        var benefit =<?php echo $benefit_first; ?>;
                        var benefit_cost = 0;
                        var benefit_per_months =<?php echo $benefit_first; ?>;
                        var step =<?php echo $step; ?>;
                    </script>
                    <div id="instalment_mode_<?php echo $c; ?>" data-min="<?php echo $min_month_first; ?>"
                         data-max="<?php echo $max_month_first; ?>" data-benefit="<?php echo $benefit_first; ?>"
                         data-available="<?php echo $mode_available_steps; ?>" class="item <?php if ($c == 1) {
                        echo "item_active";
                    } ?> installment_mode_class"><?php echo $mode->post_title; ?></div>
                <?php
                }else{
                $min_month = get_post_meta($mode->ID, "installment_min_month", true);
                $max_month = get_post_meta($mode->ID, "installment_max_month", true);
                $benefit_per_months = get_post_meta($mode->ID, "installment_monthly_benefit", true);
                $installment_1_step = get_post_meta($mode->ID, "installment_1_step", true) ?? 0;
                $installment_2_step = get_post_meta($mode->ID, "installment_2_step", true) ?? 0;
                $installment_3_step = get_post_meta($mode->ID, "installment_3_step", true) ?? 0;
                $mode_available_steps = "";
                if ($installment_1_step == 1) {
                    $mode_available_steps .= "1";
                }
                if ($installment_2_step == 1) {
                    $mode_available_steps .= ",2";
                }
                if ($installment_3_step == 1) {
                    $mode_available_steps .= ",3";
                }
                ?>
                    <div id="instalment_mode_<?php echo $c; ?>" data-min="<?php echo $min_month; ?>"
                         data-max="<?php echo $max_month; ?>" data-benefit="<?php echo $benefit_per_months; ?>"
                         data-available="<?php echo $mode_available_steps; ?>" class="item <?php if ($c == 1) {
                        echo "item_active";
                    } ?> installment_mode_class"><?php echo $mode->post_title; ?></div>
                    <?php
                }
                $c++;
            }
            ?>

        </div>
        <!--- Perpay value ------------>
        <div class="prepay_box">
            <div class="label">مبلغ پیش پرداخت را وارد کنید :</div>
            <div class="label" style="float: left; margin-right: 8px;">تومان</div>
            <input class="prepay_price_input" id="prepay_price_input" name="prepay_price_input" type="text" min="0">
        </div>
        <p class="prepay_alert" id="prepay_alert"></p>
        <!--- Select installments months ---->
        <div class="months_selection">
            <div class="installments_months_number">
                <select class="" name="installments_months_number" id="installments_months_number">
                    <option selected disabled>تعداد ماه های اقساط</option>
                    <?php
                    for ($i = $min_month_first; $i <= $max_month_first; $i++) {
                        ?>
                        <option value="<?php echo $i; ?>"><?php echo $i; ?> ماهه</option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="custom-select"></div>
            <div class="steps_btn" data-step="3" style="font-size: 12px;<?php if ($installment_3_step_first != 1) {
                echo 'display:none;';
            } ?>">هر 3 ماه
            </div>
            <div class="steps_btn" data-step="2" style="font-size: 12px;<?php if ($installment_2_step_first != 1) {
                echo 'display:none;';
            } ?>">هر 2 ماه
            </div>
            <div class="steps_btn steps_btn_active" data-step="1"
                 style="font-size: 12px;<?php if ($installment_1_step_first != 1) {
                     echo 'display:none;';
                 } ?>">ماهانه
            </div>
            <div class="steps_btn" id="payment_steps_label"
                 style="border: none;cursor: default;font-size: 12px;pointer-events: none;">پرداخت
                بصورت
            </div>
        </div>
        <!---- Show calculated result ----->
        <div class="show_calculated_result">
            <div class="title" style="font-size: 18px; width: 100%; text-align: center;">نتیجه محاسبه</div>
            <div class="title" id="product_regular_price"
                 style="width: 100%;padding-top: 15px; padding-bottom: 15px;font-size: 14px;">مبلغ نقد کالا :
                <span><?php echo number_format($product_price); ?></span> تومان
            </div>
            <div class="title" id="product_final_price"
                 style="width: 100%;padding-top: 15px; padding-bottom: 15px;font-size: 14px;">مبلغ اقساطی کالا :
                <span></span> تومان
            </div>
            <div class="title" id="total_price"
                 style="width: 100%;padding-top: 15px; padding-bottom: 15px;font-size: 14px;">مانده حساب :
                <span>100</span> تومان
            </div>
            <div class="title" id="benefit_price"
                 style="width: 100%;padding-top: 15px; padding-bottom: 15px;font-size: 14px;"> مبلغ سود اقساط : <span
                        id="cost">100</span> تومان
            </div>

            <div class="title"
                 style="font-size: 15px; width: 100%; text-align: center; margin-top: 20px;padding-top: 10px; padding-bottom: 10px;">
                مبلغ و تاریخ هر پرداخت
            </div>
            <table class="installment_table">
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <?php
});


add_shortcode("installment_calculator", function () {
    $installment_modes = get_posts(array(
        'post_type' => 'my_installment_mode',
        'posts_per_page' => -1,
        'post_status' => 'any',
    ));
    $step = 1;
    $default_loan = 0;
    ?>
    <script>
        var each_payment_price = 0;
        var prepay_cost = 0;
        var static_prepay_cost = 0;
        var final_price = 0;
        var current_product_price =<?php echo $default_loan; ?>;
    </script>
    <!--   <div class="i_would_pay_in_installments_box">
           <label for="i_would_pay_in_installments" style="height: auto;">مایل به پرداخت اقساطی می باشم</label>
           <input type="checkbox" id="i_would_pay_in_installments" name="i_would_pay_in_installments">
       </div>-->
    <div class="installment_calculator_container" style="display:block;">
        <!--- List of modes ----------->
        <div class="modes_container">
            <?php
            $c = 1;
            $mode_available_steps = "";
            foreach ($installment_modes as $mode) {
                if ($c == 1) {
                    $min_month_first = get_post_meta($mode->ID, "installment_min_month", true);
                    $max_month_first = get_post_meta($mode->ID, "installment_max_month", true);
                    $benefit_first = get_post_meta($mode->ID, "installment_monthly_benefit", true);
                    $installment_1_step_first = get_post_meta($mode->ID, "installment_1_step", true) ?? 0;
                    $installment_2_step_first = get_post_meta($mode->ID, "installment_2_step", true) ?? 0;
                    $installment_3_step_first = get_post_meta($mode->ID, "installment_3_step", true) ?? 0;
                    $mode_available_steps = "";
                    if ($installment_1_step_first == 1) {
                        $step = 1;
                    } else {
                        if ($installment_2_step_first == 1) {
                            $step = 2;
                        } else {
                            if ($installment_3_step_first == 1) {
                                $step = 3;
                            }
                        }
                    }
                    if ($installment_1_step_first == 1) {
                        $mode_available_steps .= "1";
                    }
                    if ($installment_2_step_first == 1) {
                        $mode_available_steps .= ",2";
                    }
                    if ($installment_3_step_first == 1) {
                        $mode_available_steps .= ",3";
                    }
                    ?>
                    <script>
                        var min_month =<?php echo $min_month_first ?>;
                        var max_month =<?php echo $max_month_first ?>;
                        var benefit =<?php echo $benefit_first; ?>;
                        var benefit_cost = 0;
                        var benefit_per_months =<?php echo $benefit_first; ?>;
                        var step =<?php echo $step; ?>;
                    </script>
                    <div id="instalment_mode_<?php echo $c; ?>" data-min="<?php echo $min_month_first; ?>"
                         data-max="<?php echo $max_month_first; ?>" data-benefit="<?php echo $benefit_first; ?>"
                         data-available="<?php echo $mode_available_steps; ?>" class="item <?php if ($c == 1) {
                        echo "item_active";
                    } ?> installment_mode_class"><?php echo $mode->post_title; ?></div>
                <?php
                }else{
                $min_month = get_post_meta($mode->ID, "installment_min_month", true);
                $max_month = get_post_meta($mode->ID, "installment_max_month", true);
                $benefit_per_months = get_post_meta($mode->ID, "installment_monthly_benefit", true);
                $installment_1_step = get_post_meta($mode->ID, "installment_1_step", true) ?? 0;
                $installment_2_step = get_post_meta($mode->ID, "installment_2_step", true) ?? 0;
                $installment_3_step = get_post_meta($mode->ID, "installment_3_step", true) ?? 0;
                $mode_available_steps = "";
                if ($installment_1_step == 1) {
                    $mode_available_steps .= "1";
                }
                if ($installment_2_step == 1) {
                    $mode_available_steps .= ",2";
                }
                if ($installment_3_step == 1) {
                    $mode_available_steps .= ",3";
                }
                ?>
                    <div id="instalment_mode_<?php echo $c; ?>" data-min="<?php echo $min_month; ?>"
                         data-max="<?php echo $max_month; ?>" data-benefit="<?php echo $benefit_per_months; ?>"
                         data-available="<?php echo $mode_available_steps; ?>" class="item <?php if ($c == 1) {
                        echo "item_active";
                    } ?> installment_mode_class"><?php echo $mode->post_title; ?></div>
                    <?php
                }
                $c++;
            }
            ?>

        </div>
        <!--- Perpay value ------------>
        <div class="loan_box">
            <div class="label">مبلغ کالا را وارد کنید :</div>
            <div class="label" style="float: left; margin-right: 8px;">تومان</div>
            <input class="loan_price_input" id="loan_price_input" name="loan_price_input" type="text" min="0"
                   value="<?php echo number_format($default_loan) ?>">
        </div>
        <p class="prepay_alert" id="loan_alert"></p>
        <div class="prepay_box">
            <div class="label">مبلغ پیش پرداخت را وارد کنید :</div>
            <div class="label" style="float: left; margin-right: 8px;">تومان</div>
            <input class="prepay_price_input" id="prepay_price_input" name="prepay_price_input" type="text" min="0">
        </div>
        <p class="prepay_alert" id="prepay_alert"></p>
        <!--- Select installments months ---->
        <div class="months_selection">
            <div class="installments_months_number">
                <select class="" name="installments_months_number" id="installments_months_number">
                    <option selected disabled>تعداد ماه های اقساط</option>
                    <?php
                    for ($i = $min_month_first; $i <= $max_month_first; $i++) {
                        ?>
                        <option value="<?php echo $i; ?>"><?php echo $i; ?> ماهه</option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <div class="custom-select"></div>
            <div class="steps_btn" data-step="3" style="font-size: 12px;<?php if ($installment_3_step_first != 1) {
                echo 'display:none;';
            } ?>">هر 3 ماه
            </div>
            <div class="steps_btn" data-step="2" style="font-size: 12px;<?php if ($installment_2_step_first != 1) {
                echo 'display:none;';
            } ?>">هر 2 ماه
            </div>
            <div class="steps_btn steps_btn_active" data-step="1"
                 style="font-size: 12px;<?php if ($installment_1_step_first != 1) {
                     echo 'display:none;';
                 } ?>">ماهانه
            </div>
            <div class="steps_btn" id="payment_steps_label"
                 style="border: none;cursor: default;font-size: 12px;pointer-events: none;">پرداخت
                بصورت
            </div>
        </div>
        <!---- Show calculated result ----->
        <div class="show_calculated_result">
            <div class="title" style="font-size: 20px; width: 100%; text-align: center;">نتیجه محاسبه</div>
            <div class="title" id="product_regular_price"
                 style="width: 100%;padding-top: 15px; padding-bottom: 15px;font-size: 14px;">مبلغ نقد کالا :
                <span></span> تومان
            </div>
            <div class="title" id="product_final_price"
                 style="width: 100%;padding-top: 15px; padding-bottom: 15px;font-size: 14px;">مبلغ اقساطی کالا :
                <span></span> تومان
            </div>
            <div class="title" id="total_price"
                 style="width: 100%;padding-top: 15px; padding-bottom: 15px;font-size: 14px;">مانده حساب :
                <span>100</span> تومان
            </div>
            <div class="title" id="benefit_price"
                 style="width: 100%;padding-top: 15px; padding-bottom: 15px;font-size: 14px;"> مبلغ سود اقساط : <span
                        id="cost">100</span> تومان
            </div>

            <div class="title"
                 style="font-size: 18px; width: 100%; text-align: center; margin-top: 20px;padding-top: 10px; padding-bottom: 10px;">
                مبلغ و تاریخ هر پرداخت
            </div>
            <table class="installment_table">
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <?php
});

//////////////////// Add meta box for installment modes ////////////////////////////////////////////
add_action('add_meta_boxes', 'add_product_category_metabox');
function add_product_category_metabox()
{
    add_meta_box(
        'installment_setting_metabox',
        'تنظیمات',
        'create_installments_setting_metabox',
        'my_installment_mode'
    );
}

function create_installments_setting_metabox($post)
{
    $installment_min_month = get_post_meta($post->ID, "installment_min_month", true);
    $installment_max_month = get_post_meta($post->ID, "installment_max_month", true);
    $installment_monthly_benefit = get_post_meta($post->ID, "installment_monthly_benefit", true);
    $installment_1_step = get_post_meta($post->ID, "installment_1_step", true);
    $installment_2_step = get_post_meta($post->ID, "installment_2_step", true);
    $installment_3_step = get_post_meta($post->ID, "installment_3_step", true);

    ?>
    <table class="form-table" role="presentation">
        <tbody>
        <tr>
            <th scope="row"><label for="arta_azmayesh_min_month"> ماه های اقساط از</label></th>
            <td>
                <input name="installment_min_month" type="number" id="installment_min_month"
                       value="<?php echo $installment_min_month; ?>"
                       class="regular-text" style="width: 70px;">
                ماه ، تا
                <input name="installment_max_month" type="number" id="installment_max_month"
                       value="<?php echo $installment_max_month; ?>"
                       class="regular-text" style="width: 70px;">
                ماه
            </td>

        </tr>
        <tr>
            <th scope="row"><label for="installment_monthly_benefit">درصد سود ماهانه</label></th>
            <td>
                <input name="installment_monthly_benefit" type="number" id="installment_monthly_benefit"
                       value="<?php echo $installment_monthly_benefit; ?>"
                       class="regular-text" style="width: 70px;">
                ٪

            </td>
        </tr>
        <tr>
            <th scope="row"><label for="installment_monthly_benefit">گام های پرداخت</label></th>
            <td>
                <label for="installment_1_step">1ماهه</label>
                <input type="checkbox" name="installment_1_step"
                       id="installment_1_step" <?php if ($installment_1_step == 1) {
                    echo "checked";
                } ?>>
                <label for="installment_2_step">2ماهه</label>
                <input type="checkbox" name="installment_2_step"
                       id="installment_2_step" <?php if ($installment_2_step == 1) {
                    echo "checked";
                } ?>>
                <label for="installment_3_step">3ماهه</label>
                <input type="checkbox" name="installment_3_step"
                       id="installment_3_step" <?php if ($installment_3_step == 1) {
                    echo "checked";
                } ?>>
            </td>
        </tr>
        </tbody>
    </table>
    <?php
}

add_action('save_post', 'save_installment_mode_callback');
function save_installment_mode_callback($post_id)
{
    global $post;
    if ($post->post_type == 'my_installment_mode') {
        $installment_min_month = $_POST['installment_min_month'];
        $installment_max_month = $_POST['installment_max_month'];
        $installment_monthly_benefit = $_POST['installment_monthly_benefit'];

        if (isset($_POST["installment_1_step"])) {
            update_post_meta($post->ID, "installment_1_step", 1);
        } else {
            update_post_meta($post->ID, "installment_1_step", 0);
        }
        if (isset($_POST["installment_2_step"])) {
            update_post_meta($post->ID, "installment_2_step", 1);
        } else {
            update_post_meta($post->ID, "installment_2_step", 0);
        }
        if (isset($_POST["installment_3_step"])) {
            update_post_meta($post->ID, "installment_3_step", 1);
        } else {
            update_post_meta($post->ID, "installment_3_step", 0);
        }

        update_post_meta($post->ID, "installment_min_month", $installment_min_month);
        update_post_meta($post->ID, "installment_max_month", $installment_max_month);
        update_post_meta($post->ID, "installment_monthly_benefit", $installment_monthly_benefit);
    }
}


//////////// Register PostType ////////////////////

function cptui_register_my_cpts_my_installment_mode()
{

    /**
     * Post Type: اقساط.
     */

    $labels = [
        "name" => __("اقساط", "twentytwentytwo"),
        "singular_name" => __("قسط", "twentytwentytwo"),
        "menu_name" => __("اقساط من", "twentytwentytwo"),
        "all_items" => __("همه اقساط", "twentytwentytwo"),
        "add_new" => __("افزودن", "twentytwentytwo"),
        "add_new_item" => __("افزودن قسط جدید", "twentytwentytwo"),
        "edit_item" => __("ویرایش قسط", "twentytwentytwo"),
        "new_item" => __("قسط جدید", "twentytwentytwo"),
        "view_item" => __("مشاهده قسط", "twentytwentytwo"),
        "view_items" => __("مشاهده اقساط", "twentytwentytwo"),
        "search_items" => __("جستجوی اقساط", "twentytwentytwo"),
        "not_found" => __("هیچ اقساط پیدا نشد", "twentytwentytwo"),
        "not_found_in_trash" => __("No اقساط found in trash.", "twentytwentytwo"),
        "parent" => __("والد قسط:", "twentytwentytwo"),
        "featured_image" => __("تصویر شاخص برای قسط", "twentytwentytwo"),
        "set_featured_image" => __("تنظیم تصویر شاخص برای قسط", "twentytwentytwo"),
        "remove_featured_image" => __("حذف تصویر شاخص برای قسط", "twentytwentytwo"),
        "use_featured_image" => __("استفاده به عنوان تصویر شاخص برای قسط", "twentytwentytwo"),
        "archives" => __("آرشیو قسط", "twentytwentytwo"),
        "insert_into_item" => __("درج در قسط", "twentytwentytwo"),
        "uploaded_to_this_item" => __("آپلود در قسط", "twentytwentytwo"),
        "filter_items_list" => __("لیست فیلتر اقساط", "twentytwentytwo"),
        "items_list_navigation" => __("ناوبری لیست اقساط", "twentytwentytwo"),
        "items_list" => __("لیست اقساط", "twentytwentytwo"),
        "attributes" => __("ویژگی های اقساط", "twentytwentytwo"),
        "name_admin_bar" => __("قسط", "twentytwentytwo"),
        "item_published" => __("قسط منتشر شد", "twentytwentytwo"),
        "item_published_privately" => __("قسط به صورت خصوصی منتشر شد.", "twentytwentytwo"),
        "item_reverted_to_draft" => __("قسط به پیش نویس بازگشت.", "twentytwentytwo"),
        "item_scheduled" => __("قسط زمانبندی شد", "twentytwentytwo"),
        "item_updated" => __("قسط به‌روزرسانی شد.", "twentytwentytwo"),
        "parent_item_colon" => __("والد قسط:", "twentytwentytwo"),
    ];

    $args = [
        "label" => __("اقساط", "twentytwentytwo"),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "rest_namespace" => "wp/v2",
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "can_export" => false,
        "rewrite" => ["slug" => "my_installment_mode", "with_front" => true],
        "query_var" => true,
        "supports" => ["title", "editor", "thumbnail"],
        "show_in_graphql" => false,
    ];

    register_post_type("my_installment_mode", $args);
}

add_action('init', 'cptui_register_my_cpts_my_installment_mode');