jQuery(document).ready(function (jQuery) {
    calc_prepay();

    $( ".variations" ).on( "change", function () {
        if(is_variable) {
            setTimeout(function () {
                let variable_price = jQuery(".single_variation_wrap .amount bdi").text();
                variable_price = variable_price.replace("تومان", "");
                variable_price = variable_price.replace("ریال", "");
                variable_price = variable_price.replace("$", "");
                variable_price = variable_price.replaceAll(",", "");
                current_product_price = parseInt(variable_price);
                calc_prepay();
                arta_installment_calculate();
            }, 1000);
        }
    } );

    jQuery("#i_would_pay_in_installments").on("click", function () {
        jQuery(".installment_calculator_container").slideToggle();
    });

    jQuery("#installments_months_number").on("change", function () {
        if(current_product_price > 0 && current_product_price !=""){
            jQuery("#loan_alert").text('');
            jQuery(".show_calculated_result").slideDown();
            arta_installment_calculate();
        }else{
            jQuery("#loan_alert").text(`لطفا مقدار وام را درست وارد کنید.`);
        }
    });

    jQuery("#prepay_price_input").on("input", function () {
        prepay_cost = parseInt(jQuery("#prepay_price_input").val().replace(",", ""));
        if (prepay_cost > -1 && prepay_cost <= current_product_price) {
            arta_installment_calculate();
            jQuery("#prepay_alert").text('');
        } else {
            jQuery("#prepay_alert").text(`مبلغ پیش پرداخت باید حداکثر ${separate(current_product_price)} تومان باشد.`);
        }
    });

   /* jQuery("#prepay_price_input").on("blur", function () {
        prepay_cost = parseInt(jQuery("#prepay_price_input").val().replaceAll(",", ""));
        jQuery("#prepay_price_input").attr("type","text");
        jQuery("#prepay_price_input").val(separate(prepay_cost));
    });

    jQuery("#prepay_price_input").on("focus", function () {
        prepay_cost = parseInt(jQuery("#prepay_price_input").val().replaceAll(",", ""));
        jQuery("#prepay_price_input").attr("type","number");
        jQuery("#prepay_price_input").val(prepay_cost);
    });*/

    jQuery("#loan_price_input").on("input", function () {
        current_product_price = parseInt(jQuery("#loan_price_input").val().replace(",", ""));
        if (current_product_price > 0 && current_product_price != "") {
            jQuery("#product_regular_price span").text(separate(current_product_price));
            arta_installment_calculate();
            jQuery("#loan_alert").text('');
        } else {
            jQuery("#loan_alert").text(`لطفا مقدار وام را درست وارد کنید.`);
        }
    });

    /*jQuery("#loan_price_input").on("blur", function () {
        current_product_price = parseInt(jQuery("#loan_price_input").val().replaceAll(",", ""));
        jQuery("#loan_price_input").attr("type","text");
        jQuery("#loan_price_input").val(separate(current_product_price));
    });

    jQuery("#loan_price_input").on("focus", function () {
        current_product_price = parseInt(jQuery("#loan_price_input").val().replaceAll(",", ""));
        console.log(current_product_price);
        jQuery("#loan_price_input").attr("type","number");
        jQuery("#loan_price_input").val(current_product_price);
    });*/

    jQuery(".months_selection .steps_btn").on("click", function () {
        step = parseInt($(this).attr("data-step"));
        jQuery(".months_selection .steps_btn").removeClass('steps_btn_active');
        $(this).addClass("steps_btn_active")
        arta_installment_calculate();
    });

    jQuery(".modes_container .item").on("click", function () {
        min_month = parseInt(jQuery(this).attr("data-min"));
        max_month = parseInt(jQuery(this).attr("data-max"));
        benefit_per_months = parseInt(jQuery(this).attr("data-benefit"));

        jQuery(".modes_container .item").removeClass("item_active");
        jQuery(this).addClass("item_active");

        jQuery("#installments_months_number option").remove();
        jQuery("#installments_months_number").append(`<option selected disabled>تعداد ماه های اقساط</option>`);
        for (let i = min_month; i <= max_month; i++) {
            jQuery("#installments_months_number").append(`<option  value="${i}">${i} ماه</option>`);
        }
        jQuery(".show_calculated_result").hide();
        handleSteps(jQuery(this).attr("data-available"));
        arta_installment_calculate();
    });

});

function arta_installment_calculate() {
    let selected_month = jQuery("#installments_months_number").val();
    benefit = benefit_per_months*selected_month;
    benefit_cost=((current_product_price - prepay_cost) * benefit) / 100;
    final_price = current_product_price - prepay_cost;
    final_price = parseInt(final_price + benefit_cost);
    let finalPlusBenefit=parseInt(current_product_price + benefit_cost);


    each_payment_price = parseInt(final_price / selected_month) * step;

    jQuery(".show_calculated_result #final_price span").text(separate(final_price));
    jQuery(".show_calculated_result #total_price span").text(separate(final_price));
    jQuery(".show_calculated_result #benefit_price span#cost").text(separate(benefit_cost));
    jQuery(".show_calculated_result #product_final_price span").text(separate(finalPlusBenefit));
    jQuery("#product_regular_price span").text(separate(current_product_price));
    createInstallmentTable(each_payment_price);
}

function calc_prepay() {
    prepay_cost = parseInt((current_product_price * 30) / 100);
    jQuery("#prepay_price_input").val(prepay_cost);
}

function createInstallmentTable(each_payment_price) {
    let selected_month = jQuery("#installments_months_number").val();
    jQuery(".show_calculated_result .installment_table tr").remove();

    //// Get Today in jalali and store "day" of today date in jalali
    let today = new Date();
    let day = String(today.getDate()).padStart(2, '0');
    let month = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    let year = today.getFullYear();
    let today_jalali = gregorian_to_jalali(parseInt(year), parseInt(month), parseInt(day));
    let tmp_today_jalali = today_jalali.split('-');
    let counter = 1;
    for (let i = 1; i <= selected_month; i += step) {
        today = add_months(today, step);
        let dd = String(today.getDate()).padStart(2, '0');
        let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        let yyyy = today.getFullYear();
        let today_jalali2 = gregorian_to_jalali(parseInt(yyyy), parseInt(mm), parseInt(dd));
        today_jalali2 = today_jalali2.split('-');

        if (i + step > selected_month) {
            let uncountable_payment = parseInt(selected_month % step);
            if (uncountable_payment > 0) {
                each_payment_price = parseInt(final_price / selected_month) * uncountable_payment;
            }
        }

        jQuery(".show_calculated_result .installment_table tbody").append(`
        <tr>
            <th>پرداخت ${counter}</th>
            <td colspan="2">مبلغ ${separate(each_payment_price)} تومان و سررسید پرداخت در تاریخ</td>
            <td>
                <div class="date_of_installment">
                    ${today_jalali2[0]}/${today_jalali2[1]}/${tmp_today_jalali[2]}
                </div>
            </td>
        </tr>
    `);
        counter++;
    }
}

function handleSteps(data_available){
    let available_steps=data_available.split(",");
    console.log(available_steps);
    jQuery(".months_selection .steps_btn").hide();
    jQuery("#payment_steps_label").show();
    available_steps.forEach(function(item, index){
        jQuery(".months_selection .steps_btn[data-step='"+item+"']").show();
    })
}

/////////// Custom Dropdown list box //////////////////////////////
jQuery(document).ready(function (jQuery) {
    var x, i, j, l, ll, selElmnt, a, b, c;
    /*look for any elements with the class "custom-select":*/
    x = document.getElementsByClassName("custom-select");
    l = x.length;
    for (i = 0; i < l; i++) {
        var selElmnt = x[i].getElementsByTagName("select")[0];
        ll = selElmnt.length;
        /*for each element, create a new DIV that will act as the selected item:*/
        a = document.createElement("DIV");
        a.setAttribute("class", "select-selected");
        a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
        x[i].appendChild(a);
        /*for each element, create a new DIV that will contain the option list:*/
        b = document.createElement("DIV");
        b.setAttribute("class", "select-items select-hide");

        for (j = 1; j < ll; j++) {
            /*for each option in the original select element,
            create a new DIV that will act as an option item:*/
            c = document.createElement("DIV");
            c.innerHTML = selElmnt.options[j].innerHTML;
            c.setAttribute("data-val", selElmnt.options[j].value);
            c.addEventListener("click", function (e) {
                /*when an item is clicked, update the original select box,
                and the selected item:*/
                var y, i, k, s, h, sl, yl;
                s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                sl = s.length;
                h = this.parentNode.previousSibling;
                for (i = 0; i < sl; i++) {
                    if (s.options[i].innerHTML == this.innerHTML) {
                        s.selectedIndex = i;
                        h.innerHTML = this.innerHTML;
                        y = this.parentNode.getElementsByClassName("same-as-selected");
                        yl = y.length;
                        for (k = 0; k < yl; k++) {
                            y[k].removeAttribute("class");
                        }
                        this.setAttribute("class", "same-as-selected");
                        break;
                    }
                }
                h.click();
            });
            b.appendChild(c);
        }
        x[i].appendChild(b);
        a.addEventListener("click", function (e) {
            /*when the select box is clicked, close any other select boxes,
            and open/close the current select box:*/
            e.stopPropagation();
            closeAllSelect(this);
            this.nextSibling.classList.toggle("select-hide");
            this.classList.toggle("select-arrow-active");
        });
    }

    function closeAllSelect(elmnt) {
        /*a function that will close all select boxes in the document,
        except the current select box:*/
        var x, y, i, xl, yl, arrNo = [];
        x = document.getElementsByClassName("select-items");
        y = document.getElementsByClassName("select-selected");
        xl = x.length;
        yl = y.length;
        for (i = 0; i < yl; i++) {
            if (elmnt == y[i]) {
                arrNo.push(i)
            } else {
                y[i].classList.remove("select-arrow-active");
            }
        }
        for (i = 0; i < xl; i++) {
            if (arrNo.indexOf(i)) {
                x[i].classList.add("select-hide");
            }
        }
    }

    /*if the user clicks anywhere outside the select box,
    then close all select boxes:*/
    document.addEventListener("click", closeAllSelect);
});


////////////////////// Public function ////////////////////////////////////////

function separate(Number) {
    Number += '';
    Number = Number.replace(',', '');
    x = Number.split('.');
    y = x[0];
    z = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(y))
        y = y.replace(rgx, '$1' + ',' + '$2');
    return y + z;
}

function gregorian_to_jalali(gy, gm, gd) {
    var g_d_m, jy, jm, jd, gy2, days;
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    gy2 = (gm > 2) ? (gy + 1) : gy;
    days = 355666 + (365 * gy) + ~~((gy2 + 3) / 4) - ~~((gy2 + 99) / 100) + ~~((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
    jy = -1595 + (33 * ~~(days / 12053));
    days %= 12053;
    jy += 4 * ~~(days / 1461);
    days %= 1461;
    if (days > 365) {
        jy += ~~((days - 1) / 365);
        days = (days - 1) % 365;
    }
    if (days < 186) {
        jm = 1 + ~~(days / 31);
        jd = 1 + (days % 31);
    } else {
        jm = 7 + ~~((days - 186) / 30);
        jd = 1 + ((days - 186) % 30);
    }
    return jy + "-" + jm + "-" + jd;
}

function add_months(dt, n) {
    return new Date(dt.setMonth(dt.getMonth() + n));
}
